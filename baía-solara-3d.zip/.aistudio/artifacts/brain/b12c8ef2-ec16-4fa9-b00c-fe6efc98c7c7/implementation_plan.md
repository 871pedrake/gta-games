# Baía Solara 3D — Plano da Fase 1: Desempenho e Base de Dados do Mundo

> [!IMPORTANT]
> **Escopo restrito à Fase 1.** Nenhum recurso das Fases 2–8 será implementado adiantado além da fundação arquitetural exigida pelas Regras de Engenharia (`GameEventMap`, `SAVE_SCHEMA_VERSION = 2` com migração do v1, `DEFAULT_KEY_BINDINGS` e `WorldRegistry`). Nenhuma linha de código será alterada até sua aprovação deste plano.

---

## 1. Visão Geral e Metas da Fase 1

Transformar o mapa estático e a configuração atual em uma base orientada a dados de alto desempenho para sustentar a evolução AAA das próximas fases:

- **Orçamento de Renderização:** `60 FPS` no preset **Médio** com `200 NPCs`, `30 veículos` e sombras ativas, mantendo teto de **~400 draw calls** e **~1,5M triângulos visíveis**, com telemetria completa de `renderer.info` no painel **F3**.
- **Resolução Dinâmica:** novo subsistema `PerformanceSystem` (`GameSystem`) monitorando frametime em janela móvel, reduzindo `pixelRatio` abaixo de `50 FPS` e restaurando suavemente ao estabilizar.
- **Redução Drástica de Draw Calls:** mesclagem estática por quarteirão (`mergeGeometries`) para faixas, calçadas, muretas, quadras e lotes; `InstancedMesh` para postes, semáforos, bancos, barracas, paradas de ônibus e palmeiras; `THREE.LOD` em prédios, veículos e props.
- **Mipmap, Anisotropia e Qualidade Unificada:** `QUALITY_SETTINGS` no `config.ts` passa a controlar resolução (mín/máx `pixelRatio`), sombras/resolução do shadowMap, anisotropia, mipmapping, distância de desenho (`camera.far` + fog), densidade de props/NPCs e orçamento de decais/partículas/pós-processamento.
- **Fonte Única de Dados (`WorldRegistry`):** centraliza distritos, nomes de ruas, POIs (lojas, hospital, delegacia, oficina, pontos de ônibus, bares), pontos de cobertura e spawns de eventos; `BuildingRegistry`, `ZoneDensityManager`, `Minimap`, `MissionSystem`, `NavGraph` e `TransitAndRescueSystem` passam a ler dele.
- **Carregamento Real Assíncrono & Code Splitting:** inicialização em etapas reais com `requestAnimationFrame` cedido entre blocos (`10% -> 100%`), lazy loading de UI secundária (`OptionsModal`, `PauseMenu`) e `manualChunks` no Vite.

```
┌────────────────────────────────────────────────────────────────────────────┐
│                           WorldRegistry (Dados)                            │
│  Distritos · Ruas · POIs (Lojas/Hosp/DP/Oficina/Ônibus/Bares) · Cobertura  │
└──────┬───────────────┬──────────────┬───────────────┬──────────────┬───────┘
       │               │              │               │              │
       ▼               ▼              ▼               ▼              ▼
 BuildingRegistry  ZoneDensity    NavGraph        Minimap     MissionSystem
                                                                     
┌─────────────────────────── Pipeline de Renderização ───────────────────────┐
│  config.ts (QUALITY_SETTINGS) ──► EngineSetup (async stages + LOD + merge) │
│  PerformanceSystem (GameSystem) ──► Dynamic pixelRatio (<50 FPS) + F3 info │
│  HudBridge / F3 Debug ──► calls · triangles · geometries · textures · DPR  │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Arquivos Novos

1. **`src/game/world/WorldRegistry.ts`**
   - Fonte única de verdade com dados tipados do mundo:
     - **Distritos:** `orla` (Orla da Praia), `centro` (Centro Financeiro), `residencial` (Residencial Brisa), `porto` (Porto & Marina), `parque` (Parque Solara) — com polígonos/limites `(minX, maxX, minZ, maxZ)`, cor no mapa e densidade base.
     - **Ruas e Avenidas:** mapeamento das vias em `ROAD_X` e `ROAD_Z` (*Av. Beira-Mar*, *Av. Atlântica*, *Rua das Palmeiras*, *Alameda do Sol*, *Av. do Porto*, *Rua Coral*) e helper `getStreetAndDistrictAt(x, z)`.
     - **POIs Unificados:** lojas (roupas, barbearia, armaria, oficina/pintura, mercado, concessionária — com coordenadas de porta, horário de abertura/fechamento e rótulo), hospital, delegacia, paradas de ônibus, bares noturnos, barracas, bancos, quadra de vôlei e pontos de missão.
     - **Pontos de Cobertura (`CoverPoint[]`)** e **Spawns de Eventos (`EventSpawnPoint[]`)** ancorados nos nós do `NavGraph` / quarteirões.
2. **`src/game/systems/PerformanceSystem.ts`**
   - Implementa `GameSystem` (`init`, `update`, `dispose`) registrado em `EngineSetup`.
   - Monitora FPS/frametime com janela móvel e histerese: reduz `pixelRatio` em degraus quando FPS < `50` (até o piso do preset), eleva gradualmente após estabilização acima de `56 FPS` (ignorado em WebGL por software).
   - Captura `renderer.info` pós-render (`calls`, `triangles`, `geometries`, `textures`, `programs`, `pixelRatio`, `dynamicScalePct`) e emite eventos opcionais no `EventBus`.
3. **`src/game/core/WorldBatching.ts`**
   - Helpers para mesclar geometrias estáticas por quarteirão/camada via `mergeGeometries` (`BufferGeometryUtils`), gerar grupos `InstancedMesh` para mobiliário urbano (postes, semáforos, bancos, barracas, paradas, troncos/copas de palmeiras) e montar `THREE.LOD` reutilizável para prédios e veículos (com geometrias e materiais compartilhados).
4. **`src/game/__tests__/WorldRegistry.test.ts`** e **`src/game/__tests__/SaveMigration.test.ts`**
   - Testes unitários validando cobertura de distritos/ruas/POIs no `WorldRegistry`, migração completa do save **v1 → v2** e regras de resolução dinâmica do `PerformanceSystem`.

---

## 3. Arquivos Alterados

1. **`src/game/config.ts`**
   - Atualizar `SAVE_SCHEMA_VERSION` para `2` (mantendo leitura legada `baia_solara_save_v1` para migração automática para `baia_solara_save_v2`).
   - Expandir `QUALITY_SETTINGS` por preset (`low` / `medium` / `high`): `minPixelRatio`, `maxPixelRatio`, `shadows`, `shadowMapSize`, `anisotropy`, `mipmaps`, `postProcessing`, `drawDistance`, `propDensity`, `maxDecals`, `maxParticles`.
   - Adicionar constantes de orçamento e resolução dinâmica (`TARGET_FPS_LOW_THRESHOLD = 50`, `TARGET_FPS_RECOVER_THRESHOLD = 56`, `DYNAMIC_RES_STEP`, `BUDGET_MAX_DRAW_CALLS = 400`, `BUDGET_MAX_TRIANGLES = 1_500_000`).
2. **`src/game/types.ts`**
   - Estender `GameAction` com as novas ações (`aim`, `fire`, `reload`, `weaponWheel`, `melee`, `map`, `weaponSlot1`–`weaponSlot5`).
   - Atualizar `SaveGameData` para o schema **v2** (`weapons`, `ammo`, `health`, `armor`, `outfit`, `vehicles` com `paintHex`/`customColor`/`damageRatio`, `completedEvents`, `discoveredAreas`) mantendo campos opcionais tipados de v1 para migração.
   - Adicionar `RenderTelemetry` (`calls`, `triangles`, `geometries`, `textures`, `programs`, `pixelRatio`, `drawDistance`) ao `HudSnapshot`.
3. **`src/game/core/EventBus.ts`**
   - Estender `GameEventMap` com os novos eventos padronizados: `weaponFired`, `weaponHit`, `playerDamaged`, `playerDied`, `purchaseMade`, `outfitChanged`, `shopOpened`, `randomEventStarted`, `randomEventCompleted`, `randomEventFailed`, `waypointSet`, `districtChanged` e `performanceScaled`.
4. **`src/game/core/SaveSystem.ts` e `src/game/core/SaveBridge.ts`**
   - Adicionar novas teclas padrão em `DEFAULT_KEY_BINDINGS` sem conflito com as atuais (`MouseRight`, `MouseLeft`, `KeyR`, `Tab`, `KeyV`, `KeyM`, `Digit1`–`Digit5`).
   - Implementar `migrateSaveV1ToV2(...)` no `SaveSystem.loadGame()`, lendo save v2 ou convertendo automaticamente saves existentes no `localStorage` v1 com valores iniciais consistentes (vida 100, colete 0, outfit padrão, lista vazia de eventos/áreas).
5. **`src/components/OptionsModal.tsx`**
   - Expor as novas ações remapeáveis (mira, tiro, recarregar, roda de armas, corpo a corpo, mapa), garantindo detecção de conflito ou troca segura e suporte a captura de botões do mouse quando aplicável.
6. **`src/game/world.ts`, `src/game/models.ts` e `src/game/BuildingRegistry.ts`**
   - `world.ts`: consumir `WorldRegistry` (removendo duplicação de `WORLD_POIS`, `ROAD_X`, `ROAD_Z`, `MISSION_POINTS`), agrupar faixas/zebras/lotes em malhas mescladas por quarteirão (`WorldBatching`), converter postes/semáforos/bancos/barracas/paradas/palmeiras para `InstancedMesh` e aplicar `THREE.LOD` em prédios (nível próximo completo com frisos/antenas; nível distante simplificado sem detalhes finos).
   - `models.ts`: criar texturas configuráveis por preset (`generateMipmaps`, `minFilter`, `anisotropy`) e adicionar 3 níveis de `THREE.LOD` nos veículos compartilhando geometrias/materiais em cache para evitar duplicação na GPU (mantendo exatamente o contrato `VehicleEntity` atual).
   - `BuildingRegistry.ts` e `ZoneDensityManager.ts`: ler lugares/distritos diretamente do `WorldRegistry`.
7. **`src/game/NavGraph.ts`, `src/game/systems/MissionSystem.ts`, `src/game/systems/Minimap.ts` e `src/game/TransitAndRescueSystem.ts`**
   - Passar a consultar coordenadas de ruas, paradas de ônibus, hospital, bares e pontos de missão diretamente do `WorldRegistry`.
8. **`src/game/core/SystemLifecycle.ts`, `src/game/core/EngineSetup.ts`, `src/game/core/WorldHelpers.ts`, `src/game/engine.ts` e `src/game/systems/HudBridge.ts`**
   - Tornar o bootstrap em `EngineSetup.ts` assíncrono (`createEngineRuntimeAsync`) cedendo o frame entre etapas pesadas para atualizar a barra de progresso real (`LoadingScreen`).
   - Registrar `PerformanceSystem` no pipeline de sistemas; aplicar `drawDistance` (`camera.far` + fog) e `anisotropy`/`mipmaps` ao trocar o preset em tempo real.
   - Repassar `renderer.info` + escala dinâmica para o `HudBridge`.
9. **`src/components/GameHUD.tsx`, `src/App.tsx` e `vite.config.ts`**
   - `GameHUD.tsx`: exibir `renderer.info` completo no painel **F3** (draw calls vs teto `400`, triângulos vs teto `1,5M`, geometrias, texturas, DPR ativo / resolução dinâmica).
   - `App.tsx` e `vite.config.ts`: `React.lazy` + `Suspense` para `OptionsModal` e `PauseMenu`, carregamento assíncrono do motor com progresso real e `manualChunks` no Rollup/Vite separando `three`, `react` e `lucide-react`.

---

## 4. Ordem de Migração (Passo a Passo Seguro)

1. **Contratos, Config e Save v2 (sem risco visual)**
   - Atualizar `config.ts`, `types.ts`, `EventBus.ts`, `SaveSystem.ts` (`DEFAULT_KEY_BINDINGS` + migração v1→v2) e `SaveBridge.ts`.
   - Criar `WorldRegistry.ts` mantendo exportações de compatibilidade (`ROAD_X`, `ROAD_Z`, `WORLD_POIS`, `MISSION_POINTS`) para transição sem quebras.
2. **Consumidores de Dados**
   - Migrar `BuildingRegistry.ts`, `ZoneDensityManager.ts`, `NavGraph.ts`, `MissionSystem.ts`, `Minimap.ts` e `TransitAndRescueSystem.ts` para lerem do `WorldRegistry`.
3. **Otimização de Geometria, LOD e Materiais por Preset**
   - Criar `WorldBatching.ts` e `PerformanceSystem.ts`.
   - Refatorar `models.ts` (cache de geometrias/materiais + LOD de veículos + mipmap/anisotropia por preset) e `world.ts` (mesclagem por quarteirão + `InstancedMesh` de props/palmeiras/semáforos + `THREE.LOD` em prédios).
4. **Orquestração Assíncrona, Telemetria F3 e Code Splitting**
   - Atualizar `EngineSetup.ts`, `engine.ts`, `HudBridge.ts`, `GameHUD.tsx`, `OptionsModal.tsx`, `App.tsx` e `vite.config.ts`.
5. **Testes e Validação**
   - Criar `WorldRegistry.test.ts` e `SaveMigration.test.ts`; ajustar testes existentes se necessário; rodar `tsc --noEmit`, `vitest run` e `vite build`.

---

## 5. Riscos Técnicos e Mitigações

| Risco | Impacto | Mitigação |
| :--- | :--- | :--- |
| **Alterar matrizes de instâncias/mesclagem e quebrar colisões ou semáforos dinâmicos** | Carros atravessando prédios ou semáforos que param de mudar de cor | Manter os `BuildingCollider[]` inalterados no `WorldRegistry`/`world.ts` e manter as lâmpadas dos semáforos com materiais compartilhados (`trafficLightNsMats` / `trafficLightEwMats`) em apenas 2 instâncias/meshes leves, separadas dos postes estáticos instanciados. |
| **Mesclar geometrias com atributos incompatíveis em `mergeGeometries`** | `mergeGeometries` retorna `null` se algumas geometrias tiverem `uv`/`normal` e outras não | Normalizar todos os buffers (`toNonIndexed()` e garantia de `position`/`normal`/`uv`) dentro de `WorldBatching.ts` com fallback seguro caso algum bloco falhe. |
| **Oscilação visual ("flicker") na resolução dinâmica** | Tremulação de nitidez se o FPS oscilar em torno de 50 FPS | Usar média móvel exponencial de frametime, janela mínima de cooldown (`2.0s` para subir, `0.8s` para descer) e banda morta (`< 50 FPS` reduz, `> 56 FPS` recupera). |
| **Perda de save existente dos usuários ao subir `SAVE_SCHEMA_VERSION` para 2** | Jogadores perderiam botão "Continuar" | `SaveSystem.loadGame()` lerá `baia_solara_save_v2` e, se ausente, buscará `baia_solara_save_v1`, migrando automaticamente para v2 na memória/storage. |
| **Incompatibilidade de `THREE.LOD` com `VehicleSystem` / `disposeSceneResources`** | Referências quebradas de rodas/faróis ou vazamento no `dispose` | Manter `VehicleEntity.mesh` como `THREE.Group` raiz onde os pivôs de rodas/faróis permanecem acessíveis no nível LOD0 e garantir que `disposeSceneResources` percorra objetos internos de `THREE.LOD` e `InstancedMesh`. |
| **Capturar cliques de mouse (`MouseLeft`/`MouseRight`) ao remapear teclas no `OptionsModal`** | Usuário clicar fora achando que está cancelando | No modal de opções, aceitar remap de mouse apenas quando o botão alvo estiver em modo de captura dentro da caixa dedicada (e `Esc` cancela captura). |

---

## 6. Validação Prevista ao Fim da Fase 1

- `npx tsc --noEmit` (0 erros)
- `npx vitest run` (suíte existente + novos testes de `WorldRegistry` e migração v1→v2)
- `npm run build` (`vite build` gerando chunks separados sem erros)
- Verificação em tela: Loading progressivo real -> Menu -> F3 exibindo `renderer.info` (`draw calls <= 400`, `triangles <= 1,5M`), troca de presets alterando sombras/distância/resolução e migração v1→v2 preservando progresso.
