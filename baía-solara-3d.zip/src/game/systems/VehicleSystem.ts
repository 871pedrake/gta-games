import * as THREE from 'three';
import {
  HORN_PANIC_RADIUS,
  PLAYER_RADIUS,
  VEHICLE_COLLISION_MIN_DIST,
  VEHICLE_COLLISION_RADIUS,
  VEHICLE_COAST_DAMP,
  VEHICLE_ENTER_RADIUS,
  VEHICLE_HANDBRAKE_DAMP,
  VEHICLE_WHEEL_RADIUS,
} from '../config';
import { EngineContext, GameSystem } from '../core/SystemLifecycle';
import { createVehicleEntity } from '../models';
import { VehicleEntity } from '../types';
import { MISSION_POINTS } from '../world/WorldRegistry';
import { InputManager } from './InputManager';

const _tmpColPos = new THREE.Vector3();

export class VehicleSystem implements GameSystem {
  public readonly name = 'VehicleSystem';

  private ctx: EngineContext | null = null;
  private readonly input: InputManager;
  private readonly shadowTex: THREE.CanvasTexture;

  constructor(input: InputManager, shadowTex: THREE.CanvasTexture) {
    this.input = input;
    this.shadowTex = shadowTex;
  }

  public init(ctx: EngineContext): void {
    this.ctx = ctx;

    const starterCar = createVehicleEntity(
      'starter_coupe',
      'coupe',
      0x16f2d4,
      -52,
      -16,
      0,
      this.shadowTex,
      ctx.isSoftwareGl
    );
    starterCar.driver = 'none';
    ctx.scene.add(starterCar.mesh);
    ctx.vehicles.push(starterCar);

    const m1Car = createVehicleEntity(
      'mission1_gt',
      'sports',
      0xff2e93,
      MISSION_POINTS.m1CarSpawn.x,
      MISSION_POINTS.m1CarSpawn.z,
      MISSION_POINTS.m1CarSpawn.heading,
      this.shadowTex,
      ctx.isSoftwareGl
    );
    m1Car.driver = 'none';
    m1Car.isMissionTarget = true;
    ctx.state.missionCar = m1Car;
    ctx.scene.add(m1Car.mesh);
    ctx.vehicles.push(m1Car);
  }

  public findNearestVehicle(maxDist = VEHICLE_ENTER_RADIUS): VehicleEntity | null {
    if (!this.ctx) return null;
    const { vehicles, state } = this.ctx;
    let best: VehicleEntity | null = null;
    let bestD2 = maxDist * maxDist;
    for (const v of vehicles) {
      if (v === state.currentVehicle) continue;
      const dx = v.x - state.playerPos.x;
      const dz = v.z - state.playerPos.z;
      const d2 = dx * dx + dz * dz;
      if (d2 < bestD2) {
        bestD2 = d2;
        best = v;
      }
    }
    return best;
  }

  public toggleVehicle(): void {
    if (!this.ctx) return;
    const { state, audio, transit, crowd, events, groundHeightAt, resolveWorldCollisions } = this.ctx;

    if (state.currentVehicle) {
      const car = state.currentVehicle;
      const exitX = car.x - Math.cos(car.heading) * 2.5;
      const exitZ = car.z + Math.sin(car.heading) * 2.5;
      car.driver = 'none';
      state.currentVehicle = null;
      const refY = car.mesh.position.y;
      state.playerPos.set(exitX, groundHeightAt(exitX, exitZ, refY), exitZ);
      resolveWorldCollisions(state.playerPos, PLAYER_RADIUS);
      audio.playDoorToggle();
      events.emit('vehicleExited', { vehicle: car });
      return;
    }

    const nearest = this.findNearestVehicle(VEHICLE_ENTER_RADIUS);
    if (!nearest) return;

    const wasOccupiedByNpc =
      nearest.driver === 'npc' ||
      nearest.driver === 'police' ||
      nearest.driver === 'bus' ||
      nearest.driver === 'ambulance';

    if (nearest.driver === 'bus') {
      transit.releaseBusPassengersOnHijack(nearest, crowd, groundHeightAt);
    }

    nearest.driver = 'player';
    state.currentVehicle = nearest;
    audio.playDoorToggle();

    events.emit('vehicleEntered', { vehicle: nearest, wasOccupiedByNpc });

    if (wasOccupiedByNpc) {
      events.emit('crimeCommitted', {
        minStars: nearest.type === 'ambulance' || nearest.type === 'police' ? 2 : 1,
        reason: 'Veículo tomado! Polícia acionada.',
        source: 'carjack',
      });
    }
  }

  public update(dt: number): void {
    if (!this.ctx) return;
    const { state, audio, crowd, events } = this.ctx;

    if ((state.currentVehicle || this.findNearestVehicle()) && this.input.consumeAction('interact')) {
      this.toggleVehicle();
    }

    const car = state.currentVehicle;
    if (!car) return;

    if (this.input.consumeAction('horn')) {
      audio.playHorn();
      crowd.triggerPanicRadius(car.x, car.z, HORN_PANIC_RADIUS);
      events.emit('hornHonked', { x: car.x, z: car.z });
      events.emit('bannerRequested', { text: 'Buzina! Pedestres assustados!', duration: 1.8 });
    }

    const { forward: throttle, strafe } = this.input.getMoveAxes();
    const steerInput = -strafe;
    const handbrake = this.input.isHandbrakeHeld();
    const w = this.ctx.weatherEffects;
    const grip = w.grip;

    const perfFactor = 1 - (car.damageRatio ?? 0) * 0.45;
    const effectiveAccel = car.accel * perfFactor * w.accelMult;
    const effectiveMaxSpeed = car.maxSpeed * perfFactor;

    if (throttle > 0.05) {
      car.speed += effectiveAccel * throttle * dt;
    } else if (throttle < -0.05) {
      const brakeStrength =
        car.speed > 1 ? effectiveAccel * 1.45 * w.brakeMult : effectiveAccel * 0.7;
      car.speed += brakeStrength * throttle * dt;
    } else {
      car.speed = THREE.MathUtils.damp(car.speed, 0, VEHICLE_COAST_DAMP * (0.65 + 0.35 * grip), dt);
    }

    if (handbrake) {
      car.speed = THREE.MathUtils.damp(car.speed, 0, VEHICLE_HANDBRAKE_DAMP * w.brakeMult, dt);
    }

    car.speed = THREE.MathUtils.clamp(car.speed, -11, effectiveMaxSpeed);

    const targetSteer = steerInput * 0.45;
    car.steerAngle = THREE.MathUtils.damp(car.steerAngle, targetSteer, 8 + 4 * grip, dt);
    const speedFactor = THREE.MathUtils.clamp(Math.abs(car.speed) / 7.5, 0, 1);
    const reverseSign = car.speed >= 0 ? 1 : -1;
    const turnAuthority = 0.72 + 0.28 * grip;
    car.heading += car.steerAngle * 3.1 * speedFactor * turnAuthority * reverseSign * dt;

    let lat = car.lateralSpeed ?? 0;
    const driftTrigger =
      Math.abs(car.speed) > 9 ? (handbrake ? 0.55 : w.lateralDriftMult) : 0;
    if (driftTrigger > 0.04 && Math.abs(car.steerAngle) > 0.08) {
      lat += car.steerAngle * car.speed * driftTrigger * 1.65 * dt;
    }
    lat *= Math.exp(-dt * (2.5 + 9.0 * grip));
    lat = THREE.MathUtils.clamp(lat, -9.5, 9.5);
    car.lateralSpeed = lat;

    const prevX = car.x;
    const prevZ = car.z;
    const rightX = Math.cos(car.heading);
    const rightZ = -Math.sin(car.heading);
    car.x += (Math.sin(car.heading) * car.speed + rightX * lat) * dt;
    car.z += (Math.cos(car.heading) * car.speed + rightZ * lat) * dt;

    const curY = car.mesh.position.y;
    _tmpColPos.set(car.x, curY, car.z);
    const hitBuilding = this.ctx.resolveWorldCollisions(_tmpColPos, VEHICLE_COLLISION_RADIUS);
    car.x = _tmpColPos.x;
    car.z = _tmpColPos.z;
    if (hitBuilding && Math.abs(car.speed) > 4) {
      car.speed *= -0.32;
      car.lateralSpeed = 0;
      audio.playCollision(0.7);
    }

    for (const other of this.ctx.vehicles) {
      if (other === car) continue;
      if (Math.abs(other.mesh.position.y - curY) > 2.4) continue;
      const dx = car.x - other.x;
      const dz = car.z - other.z;
      const dist = Math.hypot(dx, dz);
      if (dist < VEHICLE_COLLISION_MIN_DIST && dist > 0.001) {
        const nx = dx / dist;
        const nz = dz / dist;
        const overlap = VEHICLE_COLLISION_MIN_DIST - dist;
        car.x += nx * overlap * 0.6;
        car.z += nz * overlap * 0.6;
        other.x -= nx * overlap * 0.4;
        other.z -= nz * overlap * 0.4;

        if (Math.abs(car.speed) > 6) {
          const hitSpeed = Math.abs(car.speed);
          const intensity = hitSpeed / car.maxSpeed;
          audio.playCollision(intensity);
          crowd.triggerPanicRadius(car.x, car.z, 24);
          car.speed *= 0.55;
          const hitPolice = other.driver === 'police';
          events.emit('vehicleCollision', {
            intensity,
            x: car.x,
            z: car.z,
            hitPolice,
            speed: hitSpeed,
          });
          if (hitPolice || hitSpeed > 9) {
            events.emit('crimeCommitted', {
              minStars: hitPolice ? 2 : 1,
              reason: 'Batida de trânsito! Polícia em alerta.',
              source: 'crash',
            });
          }
        }
      }
    }

    const groundY = this.ctx.groundHeightAt(car.x, car.z, curY);
    state.playerPos.set(car.x, groundY, car.z);
    car.mesh.position.set(car.x, groundY, car.z);
    car.mesh.rotation.y = car.heading;

    const distMoved = Math.hypot(car.x - prevX, car.z - prevZ) * (car.speed >= 0 ? 1 : -1);
    car.frontWheelPivots.forEach((p) => (p.rotation.y = car.steerAngle * 0.85));
    car.wheels.forEach((wheel) => (wheel.rotation.x += distMoved / VEHICLE_WHEEL_RADIUS));

    car.taillights.forEach((tl) => {
      const m = tl.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = throttle < -0.05 || handbrake ? 2.8 : 1.1;
    });
  }

  public dispose(): void {
    this.ctx = null;
  }
}
