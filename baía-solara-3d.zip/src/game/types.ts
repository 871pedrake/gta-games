import * as THREE from 'three';
import { QualityPreset } from './config';
import { LodCounts } from './LODSystem';
import { WeaponState } from './WeaponDefs';
import { UrbanZoneId, ZoneStats } from './ZoneDensityManager';

export type VehicleType = 'sports' | 'sedan' | 'coupe' | 'police' | 'bus' | 'ambulance';

export type DriverKind = 'none' | 'npc' | 'player' | 'police' | 'bus' | 'ambulance';

export interface VehicleEntity {
  id: string;
  name: string;
  type: VehicleType;
  mesh: THREE.Group;
  frontWheelPivots: THREE.Group[];
  wheels: THREE.Mesh[];
  headlights: THREE.Mesh[];
  taillights: THREE.Mesh[];
  lightBarRed?: THREE.Mesh;
  lightBarBlue?: THREE.Mesh;
  x: number;
  z: number;
  heading: number;
  speed: number;
  steerAngle: number;
  halfWidth: number;
  halfLength: number;
  maxSpeed: number;
  accel: number;
  driver: DriverKind;
  npcAxis?: 'x' | 'z';
  npcDir?: 1 | -1;
  npcTargetSpeed?: number;
  isMissionTarget?: boolean;
  stuckTimer?: number;
  health?: number;
  maxHealth?: number;
  damageRatio?: number;
  paintHex?: number;
  lateralSpeed?: number;
  busPassengerCount?: number;
}

export type WeatherType = 'clear' | 'rain' | 'fog' | 'heat';

export interface BuildingCollider {
  x: number;
  z: number;
  halfW: number;
  halfD: number;
  height: number;
  colorHex: string;
  label?: string;
  baseY?: number;
}

export interface CashPickup {
  id: string;
  x: number;
  z: number;
  value: number;
  mesh: THREE.Group;
  collected: boolean;
  respawnTimer: number;
}

export type MissionId = 'none' | 'mission1' | 'mission2';

export interface MissionStatus {
  id: MissionId;
  step: number;
  title: string;
  objective: string;
  targetPos: { x: number; z: number } | null;
  completedMissions: string[];
}

export interface NpcDebugScreenLabel {
  id: number;
  screenX: number;
  screenY: number;
  text: string;
  subtext: string;
  hpRatio: number;
}

export type GameAction =
  | 'moveForward'
  | 'moveBackward'
  | 'moveLeft'
  | 'moveRight'
  | 'sprint'
  | 'jump'
  | 'interact'
  | 'horn'
  | 'aim'
  | 'fire'
  | 'reload'
  | 'weaponWheel'
  | 'melee'
  | 'map'
  | 'weaponSlot1'
  | 'weaponSlot2'
  | 'weaponSlot3'
  | 'weaponSlot4'
  | 'weaponSlot5'
  | 'camLeft'
  | 'camRight'
  | 'cycleWeather'
  | 'cycleTimeScale'
  | 'toggleDebug'
  | 'toggleWaypoints'
  | 'toggleColliders'
  | 'toggleRoutineLabels'
  | 'spawnTestGroup'
  | 'pause';

export type KeyBindings = Record<GameAction, string>;

export type TouchMode = 'auto' | 'on' | 'off';

export type AimMode = 'hold' | 'toggle';

export interface GameOptions {
  qualityPreset: QualityPreset;
  volume: number; // 0..1
  muted: boolean;
  cameraSensitivity: number; // 0.4..2.2
  aimMode: AimMode;
  aimSensitivityMul: number; // 0.2..1.2
  invertY: boolean;
  touchMode: TouchMode;
  keyBindings: KeyBindings;
}

export interface SavedVehicleState {
  id: string;
  x: number;
  z: number;
  heading: number;
  health: number;
  damageRatio: number;
  paintHex?: number;
  finish?: 'gloss' | 'matte' | 'metallic' | 'pearlescent';
}

export interface SavedWeaponAmmo {
  id: string;
  clip: number;
  reserve: number;
}

export interface SavedOutfitState {
  head: string;
  torso: string;
  legs: string;
  shoes: string;
  accessory: string;
  hairStyle: string;
  skinTone: string;
}

export interface SaveGameData {
  version: number;
  savedAtIso: string;
  money: number;
  health: number;
  armor: number;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  currentVehicleId: string | null;
  gameTime: number;
  dayNumber: number;
  weather: WeatherType;
  completedMissions: string[];
  weapons: SavedWeaponAmmo[];
  activeWeaponId: string;
  outfit: SavedOutfitState;
  vehicles: SavedVehicleState[];
  completedEvents: string[];
  discoveredAreas: string[];
}

export interface RenderTelemetry {
  calls: number;
  triangles: number;
  geometries: number;
  textures: number;
  programs: number;
  pixelRatio: number;
  dynamicScalePct: number;
  drawDistance: number;
  chunksTotal: number;
  chunksFull: number;
  chunksImpostor: number;
  chunksUnloaded: number;
}

export interface LoadingProgress {
  progress: number; // 0..100
  stage: string;
}

export type AppScreenState = 'loading' | 'menu' | 'playing' | 'paused';

export interface HudWeaponState {
  activeWeaponId: string;
  weaponName: string;
  slot: number;
  isFirearm: boolean;
  weaponState: WeaponState;
  clip: number;
  clipSize: number;
  reserve: number;
  reloading: boolean;
  reloadProgress: number;
  aiming: boolean;
  shoulderSide: 1 | -1;
  crosshairSpreadPx: number;
  hitMarkerAge: number;
  lastHitHeadshot: boolean;
  lastHitKill: boolean;
  ownedWeapons: SavedWeaponAmmo[];
}

export interface WeaponDebugStats {
  activeProjectiles: number;
  activeParticles: number;
  activeDecals: number;
  activeTracers: number;
  activeCasings: number;
}

export interface HudSnapshot {
  money: number;
  health: number;
  armor: number;
  wantedStars: number;
  evadingProgress: number; // 0..1 when out of sight
  bustProgress: number; // 0..1 when police pinned player
  inVehicle: boolean;
  vehicleName: string;
  vehicleHealthPct: number;
  speedKmh: number;
  nearVehiclePrompt: boolean;
  nearGunShopPrompt: boolean;
  gunShopOpen: boolean;
  weaponWheelOpen: boolean;
  isPointerLocked: boolean;
  activeWeaponId: string;
  weaponName: string;
  ammoClip: number;
  ammoReserve: number;
  isAiming: boolean;
  isReloading: boolean;
  reloadProgress: number;
  weapon: HudWeaponState;
  weaponDebug: WeaponDebugStats;
  timeOfDayLabel: string;
  gameTimeFormatted: string; // HH:MM
  isWeekend: boolean;
  dayNumber: number;
  timeScale: number; // 1, 10, 60
  timeNormalized: number; // 0..1
  weather: WeatherType;
  weatherLabel: string;
  weatherGripPct: number;
  currentDistrictName: string;
  currentStreetName: string;
  mission: MissionStatus;
  bannerText: string | null;
  bustedFlash: boolean;
  muted: boolean;
  fps: number;
  activeNpcs: number;
  backgroundNpcs: number;
  insideBuildingsNpcs: number;
  nearbyNpcs: number;
  lodCounts: LodCounts;
  maxNpcs: number;
  ragdollsInUse: number;
  ragdollsPoolSize: number;
  injuredCount: number;
  activeInjuredCount: number;
  maxInjuredCap: number;
  zoneStats: ZoneStats[];
  zoneAlerts: UrbanZoneId[];
  qualityPreset: QualityPreset;
  renderTelemetry: RenderTelemetry;
  showDebugPanel: boolean;
  busPassengersTotal: number;
  activeBuses: number;
  ambulanceStatus: string;
  trafficSignalPhase: string;
  showWaypoints: boolean;
  showColliders: boolean;
  showRoutineLabels: boolean;
  paused: boolean;
  gamepadConnected: boolean;
  lastSavedAtIso: string | null;
}
