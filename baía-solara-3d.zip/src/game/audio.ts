// Motor de áudio procedural 100% Web Audio API (sem arquivos MP3 externos)

export class ProceduralAudio {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private sirenOsc: OscillatorNode | null = null;
  private sirenGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private muted = false;
  private volume = 1.0;
  private initialized = false;
  private sirenPhase = 0;

  public isMuted(): boolean {
    return this.muted;
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        this.muted ? 0 : 0.32 * this.volume,
        this.ctx.currentTime,
        0.05
      );
    }
  }

  public setMuted(mute: boolean): void {
    this.muted = mute;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        mute ? 0 : 0.32 * this.volume,
        this.ctx.currentTime,
        0.05
      );
    }
  }

  public unlock(): void {
    if (this.initialized) {
      if (this.ctx && this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return;
    }

    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    this.ctx = new AudioCtx();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = this.muted ? 0 : 0.32;
    this.masterGain.connect(this.ctx.destination);

    // Oscilador contínuo do motor do veículo
    this.engineOsc = this.ctx.createOscillator();
    this.engineOsc.type = 'sawtooth';
    this.engineOsc.frequency.value = 52;
    const engineFilter = this.ctx.createBiquadFilter();
    engineFilter.type = 'lowpass';
    engineFilter.frequency.value = 240;
    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.value = 0;

    this.engineOsc.connect(engineFilter);
    engineFilter.connect(this.engineGain);
    this.engineGain.connect(this.masterGain);
    this.engineOsc.start();

    // Oscilador da sirene policial
    this.sirenOsc = this.ctx.createOscillator();
    this.sirenOsc.type = 'triangle';
    this.sirenOsc.frequency.value = 620;
    this.sirenGain = this.ctx.createGain();
    this.sirenGain.gain.value = 0;
    this.sirenOsc.connect(this.sirenGain);
    this.sirenGain.connect(this.masterGain);
    this.sirenOsc.start();

    // Ruído procedural de chuva (buffer de 2s filtrado em passa-baixa/banda)
    const rainLen = this.ctx.sampleRate * 2;
    const rainBuf = this.ctx.createBuffer(1, rainLen, this.ctx.sampleRate);
    const data = rainBuf.getChannelData(0);
    for (let i = 0; i < rainLen; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.55;
    }
    const rainSource = this.ctx.createBufferSource();
    rainSource.buffer = rainBuf;
    rainSource.loop = true;
    const rainFilter = this.ctx.createBiquadFilter();
    rainFilter.type = 'bandpass';
    rainFilter.frequency.value = 1150;
    rainFilter.Q.value = 0.7;
    this.rainGain = this.ctx.createGain();
    this.rainGain.gain.value = 0;
    rainSource.connect(rainFilter);
    rainFilter.connect(this.rainGain);
    this.rainGain.connect(this.masterGain);
    rainSource.start();

    this.initialized = true;
  }

  public updateContinuous(
    dt: number,
    inVehicle: boolean,
    speedRatio: number,
    sirenActive: boolean,
    rainIntensity = 0
  ): void {
    if (!this.initialized || !this.ctx || !this.engineOsc || !this.engineGain || !this.sirenOsc || !this.sirenGain) {
      return;
    }
    const now = this.ctx.currentTime;

    if (inVehicle && !this.muted) {
      const targetFreq = 48 + Math.abs(speedRatio) * 115;
      this.engineOsc.frequency.setTargetAtTime(targetFreq, now, 0.06);
      this.engineGain.gain.setTargetAtTime(0.08 + Math.abs(speedRatio) * 0.07, now, 0.08);
    } else {
      this.engineGain.gain.setTargetAtTime(0, now, 0.08);
    }

    if (sirenActive && !this.muted) {
      this.sirenPhase += dt * 4.2;
      const freq = 640 + Math.sin(this.sirenPhase) * 230;
      this.sirenOsc.frequency.setTargetAtTime(freq, now, 0.03);
      this.sirenGain.gain.setTargetAtTime(0.065, now, 0.08);
    } else {
      this.sirenGain.gain.setTargetAtTime(0, now, 0.08);
    }

    if (this.rainGain) {
      const targetRain = !this.muted && rainIntensity > 0.01 ? 0.14 * rainIntensity : 0;
      this.rainGain.gain.setTargetAtTime(targetRain, now, 0.25);
    }
  }

  public playTone(freq: number, duration: number, type: OscillatorType = 'sine', volume = 0.16, slideTo?: number): void {
    if (this.muted || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (slideTo !== undefined) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), now + duration);
    }
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + duration);
  }

  public playCashPickup(): void {
    this.playTone(587.33, 0.1, 'triangle', 0.18);
    setTimeout(() => this.playTone(880, 0.16, 'triangle', 0.18), 65);
  }

  public playJump(): void {
    this.playTone(170, 0.14, 'sine', 0.12, 340);
  }

  public playDoorToggle(): void {
    this.playTone(130, 0.09, 'square', 0.09, 75);
  }

  public playCollision(intensity = 1): void {
    const vol = Math.min(0.24, 0.08 + intensity * 0.12);
    this.playTone(95, 0.18, 'sawtooth', vol, 36);
  }

  public playMissionComplete(): void {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, idx) => {
      setTimeout(() => this.playTone(n, 0.24, 'triangle', 0.18), idx * 90);
    });
  }

  public playBusted(): void {
    this.playTone(340, 0.28, 'sawtooth', 0.18, 120);
  }

  public playHorn(): void {
    this.playTone(392, 0.22, 'sawtooth', 0.11);
    this.playTone(493.88, 0.22, 'sawtooth', 0.09);
  }

  public playImpact(strength = 1): void {
    const vol = Math.min(0.28, 0.12 + strength * 0.12);
    this.playTone(130, 0.16, 'sawtooth', vol, 42);
    this.playTone(320, 0.1, 'triangle', vol * 0.7, 110);
  }

  public playCartoonStars(): void {
    this.playTone(980, 0.09, 'sine', 0.08, 1320);
    setTimeout(() => this.playTone(1240, 0.11, 'sine', 0.08, 860), 70);
  }

  public playGunshot(weaponId: string): void {
    if (this.muted || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;

    // Estalo percussivo com ruído curto filtrado + corpo grave específico por arma
    const duration = weaponId === 'shotgun' ? 0.19 : weaponId === 'rifle' ? 0.145 : weaponId === 'smg' ? 0.085 : 0.11;
    const len = Math.max(128, Math.floor(this.ctx.sampleRate * duration));
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      const env = Math.pow(1 - i / len, weaponId === 'shotgun' ? 1.7 : 2.5);
      ch[i] = (Math.random() * 2 - 1) * env;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buf;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value =
      weaponId === 'shotgun' ? 720 : weaponId === 'rifle' ? 1420 : weaponId === 'smg' ? 1880 : 1550;
    filter.Q.value = weaponId === 'rifle' ? 0.7 : 0.85;

    const noiseGain = this.ctx.createGain();
    const vol = weaponId === 'shotgun' ? 0.34 : weaponId === 'rifle' ? 0.28 : weaponId === 'smg' ? 0.2 : 0.24;
    noiseGain.gain.setValueAtTime(vol, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.masterGain);
    noise.start(now);

    const punchFreq = weaponId === 'shotgun' ? 128 : weaponId === 'rifle' ? 205 : weaponId === 'smg' ? 245 : 210;
    this.playTone(punchFreq, duration * 0.75, 'triangle', vol * 0.65, 46);

    if (weaponId === 'rifle') {
      // Estalo supersônico agudo de fuzil
      this.playTone(2200, 0.045, 'sawtooth', 0.07, 780);
    } else if (weaponId === 'shotgun') {
      // Cauda mecânica leve de ferrolho/pump após o disparo
      setTimeout(() => this.playTone(320, 0.045, 'square', 0.04, 190), 175);
    }
  }

  public playMeleeSwing(): void {
    this.playTone(230, 0.1, 'sine', 0.11, 95);
  }

  public playReload(stage: 'mag' | 'shell' = 'mag'): void {
    if (stage === 'shell') {
      this.playTone(520, 0.045, 'triangle', 0.075, 760);
      return;
    }
    this.playTone(340, 0.06, 'square', 0.08, 460);
    setTimeout(() => this.playTone(540, 0.08, 'triangle', 0.09, 680), 110);
  }

  public playDryFire(): void {
    this.playTone(860, 0.032, 'square', 0.065, 420);
  }

  public playHitMarker(headshot = false): void {
    if (headshot) {
      this.playTone(1320, 0.07, 'sine', 0.13, 1760);
    } else {
      this.playTone(880, 0.05, 'triangle', 0.09, 660);
    }
  }

  public playBulletImpact(material: 'concrete' | 'metal' | 'terrain' | 'npc', distRatio = 0): void {
    if (this.muted || !this.ctx || !this.masterGain) return;
    const att = Math.max(0.18, 1 - Math.max(0, Math.min(1, distRatio)) * 0.8);
    if (material === 'metal') {
      this.playTone(1240, 0.09, 'triangle', 0.1 * att, 480);
      this.playTone(2180, 0.05, 'sine', 0.065 * att, 1320);
    } else if (material === 'concrete') {
      this.playTone(520, 0.055, 'sawtooth', 0.075 * att, 175);
    } else if (material === 'terrain') {
      this.playTone(165, 0.065, 'sine', 0.08 * att, 68);
    } else {
      this.playTone(290, 0.05, 'triangle', 0.085 * att, 140);
    }
  }

  public playBulletFlyby(pan = 0): void {
    if (this.muted || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1680, now);
    osc.frequency.exponentialRampToValueAtTime(410, now + 0.095);
    gain.gain.setValueAtTime(0.085, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.095);

    if (typeof this.ctx.createStereoPanner === 'function') {
      const panner = this.ctx.createStereoPanner();
      panner.pan.value = Math.max(-1, Math.min(1, pan));
      osc.connect(gain);
      gain.connect(panner);
      panner.connect(this.masterGain);
    } else {
      osc.connect(gain);
      gain.connect(this.masterGain);
    }

    osc.start(now);
    osc.stop(now + 0.098);
  }

  public dispose(): void {
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
    this.initialized = false;
  }
}
